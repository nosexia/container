import { GoogleMapConfig } from '../model/google-map-config/google-map-config'
export const googleMapConfig: GoogleMapConfig = {
    apiKey: 'AIzaSyCsZqDbruzzl8DJmHUCZ1Yvl8Z6QsbJBwM',
    language: 'en-UK'
    // zh-CN
}