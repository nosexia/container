import { RulesetRelsPipe } from './ruleset-rels.pipe';

describe('RulesetRelsPipe', () => {
  it('create an instance', () => {
    const pipe = new RulesetRelsPipe();
    expect(pipe).toBeTruthy();
  });
});
