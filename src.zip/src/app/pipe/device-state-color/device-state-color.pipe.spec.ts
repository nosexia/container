import { DeviceStateColorPipe } from './device-state-color.pipe';

describe('DeviceStateColorPipe', () => {
  it('create an instance', () => {
    const pipe = new DeviceStateColorPipe();
    expect(pipe).toBeTruthy();
  });
});
