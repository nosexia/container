import { DeviceTypePipe } from './device-type.pipe';

describe('DeviceTypePipe', () => {
  it('create an instance', () => {
    const pipe = new DeviceTypePipe();
    expect(pipe).toBeTruthy();
  });
});
