import { JourneyStatusPipe } from './journey-status.pipe';

describe('JourneyStatusPipe', () => {
  it('create an instance', () => {
    const pipe = new JourneyStatusPipe();
    expect(pipe).toBeTruthy();
  });
});
