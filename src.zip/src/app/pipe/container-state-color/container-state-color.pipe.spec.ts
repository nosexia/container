import { ContainerStateColorPipe } from './container-state-color.pipe';

describe('ContainerStateColorPipe', () => {
  it('create an instance', () => {
    const pipe = new ContainerStateColorPipe();
    expect(pipe).toBeTruthy();
  });
});
