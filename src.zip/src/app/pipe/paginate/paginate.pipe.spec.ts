import { PaginatePipe } from './paginate.pipe';

describe('PaginatePipe', () => {
  it('create an instance', () => {
    const pipe = new PaginatePipe();
    expect(pipe).toBeTruthy();
  });
});
