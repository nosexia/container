import { DeviceStatePipe } from './device-state.pipe';

describe('DeviceStatePipe', () => {
  it('create an instance', () => {
    const pipe = new DeviceStatePipe();
    expect(pipe).toBeTruthy();
  });
});
