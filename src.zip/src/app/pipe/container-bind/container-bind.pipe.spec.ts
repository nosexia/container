import { ContainerBindPipe } from './container-bind.pipe';

describe('ContainerBindPipe', () => {
  it('create an instance', () => {
    const pipe = new ContainerBindPipe();
    expect(pipe).toBeTruthy();
  });
});
