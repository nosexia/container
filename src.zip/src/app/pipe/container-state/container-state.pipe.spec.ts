import { ContainerStatePipe } from './container-state.pipe';

describe('ContainerStatePipe', () => {
  it('create an instance', () => {
    const pipe = new ContainerStatePipe();
    expect(pipe).toBeTruthy();
  });
});
