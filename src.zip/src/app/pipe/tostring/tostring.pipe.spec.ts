import { TostringPipe } from './tostring.pipe';

describe('TostringPipe', () => {
  it('create an instance', () => {
    const pipe = new TostringPipe();
    expect(pipe).toBeTruthy();
  });
});
