import { AllBindContainerPipe } from './all-bind-container.pipe';

describe('AllBindContainerPipe', () => {
  it('create an instance', () => {
    const pipe = new AllBindContainerPipe();
    expect(pipe).toBeTruthy();
  });
});
