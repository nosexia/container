export interface User {
    token: String,
    userId: Number,
    enterpriseId: Number,
    group: Number,
    username: String
}