export interface UserLoginBody {
    username: string,
    password: string
}
