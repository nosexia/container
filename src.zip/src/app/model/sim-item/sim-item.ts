export interface SimItem {
    checked: boolean,
    disabled: boolean,
    simName: String,
    iccid: String,
    imsi: String,
    id: Number,
    createdAt: String,
    data: String,
    status: Number
}
