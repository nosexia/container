export interface TerminalListBody {
    token: String,
    opUserId: Number,
    journeyId?: Number
}
