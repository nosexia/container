export interface UpdateContainerBody {
    token: String,
    opUserId: String,
    enterpriseId?: Number,
    containerId: Number,
    containerName?: String,
    rulesetName?: string,
    rulesetId?: number,
}
