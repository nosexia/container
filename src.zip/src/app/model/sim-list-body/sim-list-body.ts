export interface SimListBody {
    token: String,
    opUserId: Number,
    status?: Number
}
