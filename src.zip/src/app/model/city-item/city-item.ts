export interface CityItem {
    city: String,
    cityId: Number,
    latitude: number,
    longitude: number
}
