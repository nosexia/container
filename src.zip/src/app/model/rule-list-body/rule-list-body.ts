export interface RuleListBody {
    token: String,
    opUserId: Number,
    sensorName?: String,
    sensorTag?: String,
    groupId?: String,
    groupType?: number
}
