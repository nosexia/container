export interface RuleListBody {
    token: String,
    opUserId: Number,
    sensorName?: String,
    sensorTag?: String,
    groupId?: any,
    groupType?: Number
}
