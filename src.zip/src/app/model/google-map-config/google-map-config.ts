export interface GoogleMapConfig {
    apiKey: string,
    language: string
}
