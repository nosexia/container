export interface ContainerListBody {
    opUserId: Number,
    token: String,
    enterpriseId?: Number,
    containerId?: Number,
    journeyId?: number
}
