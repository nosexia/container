export interface QueryType {
    label: String,
    value: String
}
