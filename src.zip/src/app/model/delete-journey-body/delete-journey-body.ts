export interface DeleteJourneyBody {
    token: String,
    opUserId: Number,
    journeyId: Number
}
