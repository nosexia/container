export interface HttpConfig {
    login?: string
}
