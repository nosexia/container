export interface UpdateDevice {
    token: String,
    opUserId: number,
    enterpriseId: String,
    deviceName: String
}
