export interface GetEnterpriseListBody {
    enterpriseName?: String,
    contactName?: String,
    contactNo?: String,
    email?: String,
    token: String,
    enterpriseId?: Number,
    opUserId: Number
}
