export interface UpdateRuleBody {
    token: String,
    opUserId: Number,
    confId: Number,
    ruleValue: Number,
    groupId?: Number
}
