import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-device-charts',
  templateUrl: './device-charts.component.html',
  styleUrls: ['./device-charts.component.less']
})
export class DeviceChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
